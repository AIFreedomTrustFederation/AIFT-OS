# booksmith-ai

## Git
```text
```

## Detected Commands
```text
npm:dev=npm run dev
npm:build=npm run build
npm:start=npm run start
npm:lint=npm run lint
npm:ensure:book-folders=npm run ensure:book-folders
npm:validate:library=npm run validate:library
npm:latex:sample=npm run latex:sample
npm:latex:sample:lua=npm run latex:sample:lua
npm:fhqcm:images=npm run fhqcm:images
npm:fhqcm:polish=npm run fhqcm:polish
npm:latex:sample:tectonic=npm run latex:sample:tectonic
npm:render:latex=npm run render:latex
npm:render:latex:fhqcm=npm run render:latex:fhqcm
npm:proof:report=npm run proof:report
npm:proof:report:fhqcm=npm run proof:report:fhqcm
npm:validate:latex-integrity=npm run validate:latex-integrity
npm:validate:latex-integrity:fhqcm=npm run validate:latex-integrity:fhqcm
npm:quality:gate=npm run quality:gate
npm:quality:gate:fhqcm=npm run quality:gate:fhqcm
npm:packet:build=npm run packet:build
npm:packet:build:fhqcm=npm run packet:build:fhqcm
npm:phase1:pipeline=npm run phase1:pipeline
npm:phase1:pipeline:fhqcm=npm run phase1:pipeline:fhqcm
npm:proof:autofix=npm run proof:autofix
npm:proof:autofix:fhqcm=npm run proof:autofix:fhqcm
npm:proof:limit=npm run proof:limit
npm:proof:limit:fhqcm=npm run proof:limit:fhqcm
npm:phase1:strict-proof=npm run phase1:strict-proof
npm:phase1:strict-proof:fhqcm=npm run phase1:strict-proof:fhqcm
npm:zip:latest=npm run zip:latest
npm:zip:latest:fhqcm=npm run zip:latest:fhqcm
npm:repair:proof=npm run repair:proof
npm:repair:proof:fhqcm=npm run repair:proof:fhqcm
npm:repair:queue=npm run repair:queue
npm:repair:queue:fhqcm=npm run repair:queue:fhqcm
npm:proof:v2=npm run proof:v2
npm:proof:v2:fhqcm=npm run proof:v2:fhqcm
npm:proof:repair:v2=npm run proof:repair:v2
npm:proof:repair:v2:fhqcm=npm run proof:repair:v2:fhqcm
npm:phase1:repair:v2=npm run phase1:repair:v2
npm:phase1:repair:v2:fhqcm=npm run phase1:repair:v2:fhqcm
npm:json:repair=npm run json:repair
npm:json:validate=npm run json:validate
npm:latex:structure=npm run latex:structure
npm:latex:structure:fhqcm=npm run latex:structure:fhqcm
npm:typography:v3=npm run typography:v3
npm:typography:v3:fhqcm=npm run typography:v3:fhqcm
npm:phase1:typography:v3=npm run phase1:typography:v3
npm:phase1:typography:v3:fhqcm=npm run phase1:typography:v3:fhqcm
npm:proof:visual=npm run proof:visual
npm:proof:visual:fhqcm=npm run proof:visual:fhqcm
npm:phase1:visual-proof=npm run phase1:visual-proof
npm:phase1:visual-proof:fhqcm=npm run phase1:visual-proof:fhqcm
npm:source-map:latex=npm run source-map:latex
npm:source-map:latex:fhqcm=npm run source-map:latex:fhqcm
npm:source-map:diagnostics=npm run source-map:diagnostics
npm:source-map:diagnostics:fhqcm=npm run source-map:diagnostics:fhqcm
npm:phase1:source-mapped-proof=npm run phase1:source-mapped-proof
npm:phase1:source-mapped-proof:fhqcm=npm run phase1:source-mapped-proof:fhqcm
npm:proof:v3:context=npm run proof:v3:context
npm:proof:v3:context:fhqcm=npm run proof:v3:context:fhqcm
npm:proof:v3:plan=npm run proof:v3:plan
npm:proof:v3:plan:fhqcm=npm run proof:v3:plan:fhqcm
npm:proof:v3:apply-one=npm run proof:v3:apply-one
npm:proof:v3=npm run proof:v3
npm:proof:v3:fhqcm=npm run proof:v3:fhqcm
npm:typography:diagnostics:v4=npm run typography:diagnostics:v4
npm:typography:diagnostics:v4:fhqcm=npm run typography:diagnostics:v4:fhqcm
npm:phase1:typography-diagnostics:v4=npm run phase1:typography-diagnostics:v4
npm:phase1:typography-diagnostics:v4:fhqcm=npm run phase1:typography-diagnostics:v4:fhqcm
npm:proof:context=npm run proof:context
npm:proof:context:fhqcm=npm run proof:context:fhqcm
npm:proof:architecture-check=npm run proof:architecture-check
npm:proof:architecture-check:fhqcm=npm run proof:architecture-check:fhqcm
npm:phase1:architecture:v4=npm run phase1:architecture:v4
npm:phase1:architecture:v4:fhqcm=npm run phase1:architecture:v4:fhqcm
npm:proof:semantic-context:v4=npm run proof:semantic-context:v4
npm:proof:semantic-context:v4:fhqcm=npm run proof:semantic-context:v4:fhqcm
npm:proof:semantic-plan:v4=npm run proof:semantic-plan:v4
npm:proof:semantic-plan:v4:fhqcm=npm run proof:semantic-plan:v4:fhqcm
npm:proof:semantic-apply:v4=npm run proof:semantic-apply:v4
npm:phase1:semantic:v4=npm run phase1:semantic:v4
npm:phase1:semantic:v4:fhqcm=npm run phase1:semantic:v4:fhqcm
npm:semantic:blocks=npm run semantic:blocks
npm:semantic:blocks:fhqcm=npm run semantic:blocks:fhqcm
npm:phase1:semantic-blocks:v1=npm run phase1:semantic-blocks:v1
npm:phase1:semantic-blocks:v1:fhqcm=npm run phase1:semantic-blocks:v1:fhqcm
npm:figure:audit=npm run figure:audit
npm:figure:audit:fhqcm=npm run figure:audit:fhqcm
npm:phase1:figure-audit:v1=npm run phase1:figure-audit:v1
npm:phase1:figure-audit:v1:fhqcm=npm run phase1:figure-audit:v1:fhqcm
npm:figures:registry=npm run figures:registry
npm:figures:registry:fhqcm=npm run figures:registry:fhqcm
npm:registry:build=npm run registry:build
npm:validate:library:v2=npm run validate:library:v2
npm:publication:gate:v2=npm run publication:gate:v2
npm:publication:gate:v2:fhqcm=npm run publication:gate:v2:fhqcm
npm:booksmith:stabilize-submit=npm run booksmith:stabilize-submit
npm:booksmith:stabilize-submit:fhqcm=npm run booksmith:stabilize-submit:fhqcm
npm:bibliography:audit:v2=npm run bibliography:audit:v2
npm:bibliography:audit:v2:fhqcm=npm run bibliography:audit:v2:fhqcm
npm:bibliography:stub:v2=npm run bibliography:stub:v2
npm:bibliography:stub:v2:fhqcm=npm run bibliography:stub:v2:fhqcm
npm:bibliography:pipeline:v2=npm run bibliography:pipeline:v2
npm:bibliography:pipeline:v2:fhqcm=npm run bibliography:pipeline:v2:fhqcm
npm:reference:intelligence:v1=npm run reference:intelligence:v1
npm:reference:intelligence:v1:fhqcm=npm run reference:intelligence:v1:fhqcm
npm:figure:intelligence:v1=npm run figure:intelligence:v1
npm:figure:intelligence:v1:fhqcm=npm run figure:intelligence:v1:fhqcm
npm:publication:engine:v1=npm run publication:engine:v1
npm:publication:engine:v1:fhqcm=npm run publication:engine:v1:fhqcm
npm:booksmith:publish=npm run booksmith:publish
npm:booksmith:publish:fhqcm=npm run booksmith:publish:fhqcm
npm:artifacts:manage:v1=npm run artifacts:manage:v1
npm:artifacts:manage:v1:fhqcm=npm run artifacts:manage:v1:fhqcm
npm:booksmith:publish-managed=npm run booksmith:publish-managed
npm:booksmith:publish-managed:fhqcm=npm run booksmith:publish-managed:fhqcm
npm:booksmith:os=npm run booksmith:os
npm:booksmith:os:fhqcm=npm run booksmith:os:fhqcm
npm:booksmith:os:submit:fhqcm=npm run booksmith:os:submit:fhqcm
npm:figure:engine=npm run figure:engine
npm:figure:queue=npm run figure:queue
npm:figure:import=npm run figure:import
npm:figure:approve=npm run figure:approve
npm:figure:reject=npm run figure:reject
npm:figure:pipeline:v1=npm run figure:pipeline:v1
npm:figure:pipeline:v1:fhqcm=npm run figure:pipeline:v1:fhqcm
npm:figure:studio=npm run figure:studio
npm:figure:studio:fhqcm=npm run figure:studio:fhqcm
npm:figure:revise=npm run figure:revise
npm:figure:studio:pipeline=npm run figure:studio:pipeline
npm:figure:studio:pipeline:fhqcm=npm run figure:studio:pipeline:fhqcm
npm:figure:art-director=npm run figure:art-director
npm:figure:art-director:fhqcm=npm run figure:art-director:fhqcm
npm:figure:art-director:pipeline=npm run figure:art-director:pipeline
npm:figure:art-director:pipeline:fhqcm=npm run figure:art-director:pipeline:fhqcm
npm:studio:figures:prepare=npm run studio:figures:prepare
npm:studio:dev=npm run studio:dev
npm:system:health=npm run system:health
npm:studio=npm run studio
npm:bootstrap=npm run bootstrap
npm:server=npm run server
npm:install:termux=npm run install:termux
npm:server:fhqcm=npm run server:fhqcm
npm:install:missing-tools=npm run install:missing-tools
aift:status.sh=sh .aift/commands/status.sh
```

## Logs

### npm-build.log
```text
REPO=booksmith-ai
LABEL=npm-build
CMD=npm ci && npm run build
DATE=Sat Jun 27 17:55:44 PDT 2026

/data/data/com.termux/files/usr/bin/sh: 3: source: not found

added 357 packages, and audited 358 packages in 41s

144 packages are looking for funding
  run `npm fund` for details

2 moderate severity vulnerabilities

To address all issues (including breaking changes), run:
  npm audit fix --force

Run `npm audit` for details.
npm warn allow-scripts 3 packages have install scripts not yet covered by allowScripts:
npm warn allow-scripts   esbuild@0.28.1 (postinstall: node install.js)
npm warn allow-scripts   sharp@0.34.5 (install: node install/check.js || npm run build)
npm warn allow-scripts   unrs-resolver@1.12.2 (postinstall: node postinstall.js)
npm warn allow-scripts
npm warn allow-scripts Run `npm approve-scripts --allow-scripts-pending` to review, or `npm approve-scripts <pkg>` to allow.

> booksmith-ai@0.1.0 build
> next build

  Downloading swc package @next/swc-wasm-nodejs... to /data/data/com.termux/files/home/.cache/next-swc
  Skipping creating a lockfile at /data/data/com.termux/files/home/AIFT/booksmith-ai/.next/lock because we're using WASM bindings
▲ Next.js 16.2.9 (Turbopack)

  Creating an optimized production build ...

> Build error occurred
Error: Turbopack is not supported on this platform (android/arm64) because native bindings are not available. Only WebAssembly (WASM) bindings were loaded, and Turbopack requires native bindings.

To build on this platform, use Webpack instead:
  next build --webpack

For more information, see: https://nextjs.org/docs/app/api-reference/turbopack#supported-platforms
    at ignore-listed frames
```
