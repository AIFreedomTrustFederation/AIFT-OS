# Orphaned Capabilities

